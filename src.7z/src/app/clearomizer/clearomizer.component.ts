import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clearomizer',
  templateUrl: './clearomizer.component.html',
  styleUrls: ['./clearomizer.component.css']
})
export class ClearomizerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
